ALTER TABLE orders ADD COLUMN estimated_delivery_minutes INT DEFAULT 45;
